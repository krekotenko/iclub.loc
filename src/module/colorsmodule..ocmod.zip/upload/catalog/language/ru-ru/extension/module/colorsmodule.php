<?php
$_['heading_title'] = 'Заголовок модуля';

