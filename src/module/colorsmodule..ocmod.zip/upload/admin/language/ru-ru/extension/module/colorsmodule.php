<?php
$_['heading_title'] = 'Выбор цветов';
$_['entry_status'] = 'Статус';
$_['entry_alias'] = 'Псевдоним модуля';

